PUT YOUR CAKE PHOTOS IN THIS FOLDER (cake_photos)

File name rules:
- No hyphen needed. Use the flavour / type / shape name, then a number.
- Example: blackforest1.jpg, blackforest2.jpg, redvelvetheart.jpg, dripcake1.jpg, tier1.jpg
- You can put flavour + shape together: strawberryheart1.jpg
- Formats: jpg, jpeg, png, webp

FLAVOUR names:
  Chocolate  ->  chocolate1.jpg
  Choco Truffle  ->  chocotruffle1.jpg
  Double Chocolate  ->  doublechocolate1.jpg
  Lotus Biscoff  ->  lotusbiscoff1.jpg
  Strawberry  ->  strawberry1.jpg
  Mango  ->  mango1.jpg
  Orange  ->  orange1.jpg
  Nutella  ->  nutella1.jpg
  Cheesecake  ->  cheesecake1.jpg
  Baskin Burn Cheesecake  ->  baskinburncheesecake1.jpg
  Vancho  ->  vancho1.jpg
  Black Currant  ->  blackcurrant1.jpg
  Black Forest  ->  blackforest1.jpg
  White Forest  ->  whiteforest1.jpg
  Blueberry  ->  blueberry1.jpg
  Blue Velvet  ->  bluevelvet1.jpg
  Red Velvet  ->  redvelvet1.jpg
  Vanilla  ->  vanilla1.jpg
  Butterscotch  ->  butterscotch1.jpg
  Rasamalai  ->  rasamalai1.jpg
  Dark Chocolate  ->  darkchocolate1.jpg
  White Chocolate  ->  whitechocolate1.jpg
  Pineapple  ->  pineapple1.jpg
  Pista  ->  pista1.jpg
  Butter Pecan  ->  butterpecan1.jpg
  Coffee Mocha  ->  coffeemocha1.jpg
  Tiramisu  ->  tiramisu1.jpg
  Caramel  ->  caramel1.jpg
  Oreo  ->  oreo1.jpg
  KitKat  ->  kitkat1.jpg
  Ferrero Rocher  ->  ferrerorocher1.jpg
  Rainbow  ->  rainbow1.jpg
  Blueberry Cheesecake  ->  blueberrycheesecake1.jpg
  Strawberry Cheesecake  ->  strawberrycheesecake1.jpg
  Plum Fruit Cake  ->  plumfruitcake1.jpg

CAKE TYPE names:
  Regular Sponge Cake  ->  regularspongecake1.jpg
  Cream Cake  ->  creamcake1.jpg
  Fondant Cake  ->  fondantcake1.jpg
  Photo Cake  ->  photocake1.jpg
  Cheesecake  ->  cheesecake1.jpg
  Cupcakes  ->  cupcakes1.jpg
  Drip Cake  ->  dripcake1.jpg
  Naked Cake  ->  nakedcake1.jpg
  Semi-Naked Cake  ->  seminakedcake1.jpg
  Tier Cake  ->  tiercake1.jpg
  Bento Cake  ->  bentocake1.jpg
  Jar Cake  ->  jarcake1.jpg
  Pull-Me-Up Cake  ->  pullmeupcake1.jpg
  Barbie Doll Cake  ->  barbiedollcake1.jpg
  Number Cake  ->  numbercake1.jpg
  Alphabet Cake  ->  alphabetcake1.jpg
  Cartoon Cake  ->  cartooncake1.jpg
  Cake Pops  ->  cakepops1.jpg
  Brownie Cake  ->  browniecake1.jpg
  Mousse Cake  ->  moussecake1.jpg
  Ice Cream Cake  ->  icecreamcake1.jpg
  Eggless Cake  ->  egglesscake1.jpg
  Sugar-Free Cake  ->  sugarfreecake1.jpg
  Vegan Cake  ->  vegancake1.jpg
  Pinata Cake  ->  pinatacake1.jpg
  Mirror Glaze Cake  ->  mirrorglazecake1.jpg
  Lava Cake  ->  lavacake1.jpg
  Rainbow Layer Cake  ->  rainbowlayercake1.jpg
  Theme Cake  ->  themecake1.jpg
  Wedding Cake  ->  weddingcake1.jpg
  Truffle Cake  ->  trufflecake1.jpg
  Dream Cake  ->  dreamcake1.jpg
  Cheese Tart Cake  ->  cheesetartcake1.jpg
  Fruit Cake  ->  fruitcake1.jpg
  Custom Design Cake  ->  customdesigncake1.jpg

SHAPE names:
  Round  ->  round1.jpg
  Square  ->  square1.jpg
  Rectangle  ->  rectangle1.jpg
  Heart  ->  heart1.jpg
  2 Tier  ->  2tier1.jpg
  3 Tier  ->  3tier1.jpg